package com.example.week2application;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_start);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String msg = extras.getString("message");
            TextView textView = findViewById(R.id.textViewOutput);
            if (textView != null) {
                textView.setText(msg);
            }
        }

        Button button = findViewById(R.id.buttonUIEvent);
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(StartActivity.this, MainActivity.class);
                    intent.putExtra("message", "Hello World!");
                    startActivity(intent);
                }
            });
        }

        Button locationButton = findViewById(R.id.LocationServices);
        if (locationButton != null) {
            locationButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(StartActivity.this, LocationServicesActivity.class);
                    startActivity(intent);
                }
            });
        }

        Button mlKitButton = findViewById(R.id.button);
        if (mlKitButton != null) {
            mlKitButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
                    startActivity(intent);
                }
            });
        }

        Button animationButton = findViewById(R.id.Animation);
        if (animationButton != null) {
            animationButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(StartActivity.this, AnimationActivity.class);
                    startActivity(intent);
                }
            });
        }

        Button multimediaButton = findViewById(R.id.Multimedia);
        if (multimediaButton != null) {
            multimediaButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(StartActivity.this, MultimediaActivity.class);
                    startActivity(intent);
                }
            });
        }

        Button sqliteButton = findViewById(R.id.SQLite);
        if (sqliteButton != null) {
            sqliteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(StartActivity.this, SQLiteActivity.class);
                    startActivity(intent);
                }
            });
        }
    }
}
